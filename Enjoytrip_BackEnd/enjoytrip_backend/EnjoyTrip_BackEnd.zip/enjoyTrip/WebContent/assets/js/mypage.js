function goprivacy() {
  document.getElementById("privacywindow").style.display = 'block';
  document.getElementById("passwordchangewindow").style.display = 'none';
}

function gochange() {
  document.getElementById("privacywindow").style.display = 'none';
  document.getElementById("passwordchangewindow").style.display = 'block';
}

