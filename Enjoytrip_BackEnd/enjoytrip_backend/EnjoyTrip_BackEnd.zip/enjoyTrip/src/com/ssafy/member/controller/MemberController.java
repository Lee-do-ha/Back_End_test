package com.ssafy.member.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.board.model.BoardDto;
import com.ssafy.member.model.MemberDto;
import com.ssafy.member.model.service.MemberService;
import com.ssafy.member.model.service.MemberServiceImpl;

@WebServlet("/member")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private MemberService memberService;

	public void init() {
		memberService = MemberServiceImpl.getMemberService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		String path = "";
		if ("regist".equals(action)) {
			path = regist(request, response);
			redirect(request, response, path);
		} else if ("login".equals(action)) {
			path = login(request, response);
			forward(request, response, path);
		} else if ("logout".equals(action)) {
			path = logout(request, response);
			redirect(request, response, path);
		} else if ("info".equals(action)) {
			path = info(request, response);
			forward(request, response, path);
		} else if ("change".equals(action)) {
			path = change(request, response);
			forward(request, response, path);
		} else if ("remove".equals(action)) {
			path = remove(request, response);
			forward(request, response, path);
		} else {
			redirect(request, response, path);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

	private void redirect(HttpServletRequest request, HttpServletResponse response, String path) throws IOException {
		response.sendRedirect(request.getContextPath() + path);
	}

	private void forward(HttpServletRequest request, HttpServletResponse response, String path)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}

	private String regist(HttpServletRequest request, HttpServletResponse response) {
		// TODO : 이름, 아이디, 비밀번호, 이메일등 회원정보를 받아 MemberDto로 setting.
		MemberDto memberDto = new MemberDto();
		String userId = request.getParameter("regist-id");
		String userPwd = request.getParameter("regist-pwd");
		String userName = request.getParameter("regist-name");
		String emailId = request.getParameter("regist-email-id");
		String emailDomain = request.getParameter("regist-email-domain");

		memberDto.setUserId(userId);
		memberDto.setUserPwd(userPwd);
		memberDto.setUserName(userName);
		memberDto.setEmailId(emailId);
		memberDto.setEmailDomain(emailDomain);
		// TODO : 위의 데이터를 이용하여 service의 joinMember() 호출.
		try {
			memberService.joinMember(memberDto);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "회원가입 실패!");
			return "/error/error.jsp";
		}
		// TODO : 정상 등록 후 로그인 페이지로 이동.
		return "/index.jsp";
	}

	private String login(HttpServletRequest request, HttpServletResponse response) {
		String userId = request.getParameter("login-id");
		String userPwd = request.getParameter("login-pwd");
		try {
			MemberDto memberDto = memberService.loginMember(userId, userPwd);
			if (memberDto != null) {
//				session 설정
				HttpSession session = request.getSession();
				session.setAttribute("userInfo", memberDto);

				return "/index.jsp";
			} else {
				request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 다시 로그인하세요.");
				return "/index.jsp";
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "로그인 실패!");
			return "/error/error.jsp";
		}
	}

	private String logout(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
//		session.removeAttribute("userinfo");
		session.invalidate();
		return "";
	}

	private String info(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userInfo");
		if (memberDto != null) {
			return "/view/mypage.jsp";
		} else {
			return "/index.jsp";
		}
	}

	private String change(HttpServletRequest request, HttpServletResponse response) {
		String userId = request.getParameter("set-id");
		String userPwd = request.getParameter("set-pwd");
		try {
			memberService.changePwd(userId, userPwd);
			return "/index.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "비밀번호 변경 실패!");
			return "/error/error.jsp";
		}
	}
	
	private String remove(HttpServletRequest request, HttpServletResponse response) {
		String userId = request.getParameter("set-id");
		try {
			memberService.removeMember(userId);
			HttpSession session = request.getSession();
//			session.removeAttribute("userinfo");
			session.invalidate();
			request.setAttribute("msg", "회원탈퇴가 완료되었습니다!!");
			return "/index.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "회원 삭제 실패!!");
			return "/error/error.jsp";
		}
	}

}
