package com.ssafy.member.model.dao;

import java.sql.SQLException;

import com.ssafy.member.model.MemberDto;

public interface MemberDao {

	int joinMember(MemberDto memberDto) throws SQLException;

	MemberDto loginMember(String userId, String userPwd) throws SQLException;

	int updateMember(String userId, String userPwd) throws SQLException;
	int deleteMember(String userId) throws SQLException;

}
