package com.ssafy.member.model.service;

import com.ssafy.member.model.MemberDto;

public interface MemberService {

	int joinMember(MemberDto memberDto) throws Exception;
	MemberDto loginMember(String userId, String userPwd) throws Exception;
	int changePwd(String userId, String userPwd) throws Exception;
	int removeMember(String userId) throws Exception;
	
}
